

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        //  Uygulama başlatıldıktan sonra özelleştirme noktasını geçersiz kılma.
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Uygulama etkin durumdan etkin olmayan duruma geçmek üzereyken gönderilir. Bu, bazı geçici kesintiler (gelen telefon araması veya SMS mesajı gibi) için veya kullanıcı uygulamadan çıkıp arka plan durumuna geçmeye başladığında oluşabilir.
        // Devam eden görevleri duraklatmak, zamanlayıcıları devre dışı bırakmak ve grafik oluşturma geri çağrılarını geçersiz kılmak için bu yöntemi kullanın. Oyunlar oyunu duraklatmak için bu yöntemi kullanmalıdır.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Paylaşılan kaynakları serbest bırakmak, kullanıcı verilerini kaydetmek, zamanlayıcıları geçersiz kılmak ve daha sonra sonlandırılması durumunda uygulamanızı geçerli durumuna geri yüklemek için yeterli uygulama durumu bilgisi depolamak için bu yöntemi kullanın.
        
        // Uygulamanız arka plan yürütmeyi destekliyorsa, applicationWillTerminate: kullanıcı bıraktığında bu yöntem çağrılır.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Arka plandan aktif duruma geçişin bir parçası olarak çağrılır; burada arka plana girerken yapılan değişikliklerin çoğunu geri alabilirsiniz.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Uygulama etkin değilken duraklatılmış (veya henüz başlatılmamış) görevleri yeniden başlatın. Uygulama önceden arka planda ise, isteğe bağlı olarak kullanıcı arabirimini yenileyin.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Uygulama sona ermek üzereyken çağrılır. Gerekirse verileri kaydedin. Ayrıca bkz. ApplicationDidEnterBackground :.
    }


}

