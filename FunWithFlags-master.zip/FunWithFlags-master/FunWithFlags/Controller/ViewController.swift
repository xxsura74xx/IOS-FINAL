import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var questionCounter: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var progressView: UIView!
    @IBOutlet weak var flagView: UIImageView!
    @IBOutlet weak var questionLabel: UILabel!
    
    //Outlet for Buttons
    @IBOutlet weak var secenekA: UIButton!
    @IBOutlet weak var optionB: UIButton!
    @IBOutlet weak var optionC: UIButton!
    @IBOutlet weak var optionD: UIButton!
    
    let allQuestions = QuestionBank()
    var questionNumber: Int = 0
    var score: Int = 0
    var selectedAnswer: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateQuestion()
        updateUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func answerPressed(_ sender: UIButton) {
        if sender.tag == selectedAnswer {
            ProgressHUD.showSuccess("Doğru")
            score += 1
            
        }else{
            ProgressHUD.showError("Yanlış")
            
            
        }
        
        questionNumber += 1
        updateQuestion()
        
    }
    
    func updateQuestion(){
        
        if questionNumber <= allQuestions.list.count - 1{
            flagView.image = UIImage(named:(allQuestions.list[questionNumber].questionImage))
            questionLabel.text = allQuestions.list[questionNumber].soru
            secenekA.setTitle(allQuestions.list[questionNumber].secenekA, for: UIControlState.normal)
            optionB.setTitle(allQuestions.list[questionNumber].secenekB, for: UIControlState.normal)
            optionC.setTitle(allQuestions.list[questionNumber].secenekC, for: UIControlState.normal)
            optionD.setTitle(allQuestions.list[questionNumber].secenekD, for: UIControlState.normal)
            selectedAnswer = allQuestions.list[questionNumber].dogruCevap
            updateUI()
            
        }else {
            let alert = UIAlertController(title: "Müthiş", message: "Sınav sonu. Baştan başlamak ister misiniz?", preferredStyle: .alert)
            let restartAction = UIAlertAction(title: "Tekrar başlat", style: .default, handler: {action in self.restartQuiz()})
            alert.addAction(restartAction)
            present(alert, animated: true, completion: nil)
        }
        
        
    }
    
    func updateUI(){
        scoreLabel.text = "Puan: \(score)"
        questionCounter.text = "\(questionNumber + 1)/\(allQuestions.list.count)"
        progressView.frame.size.width = (view.frame.size.width / CGFloat(allQuestions.list.count)) * CGFloat(questionNumber + 1)
        
    }
    
    func restartQuiz(){
        score = 0
        questionNumber = 0
        updateQuestion()
        
    }
    


}

