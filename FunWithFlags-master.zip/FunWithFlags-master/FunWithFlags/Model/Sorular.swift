
import Foundation

class Sorular {
    let questionImage: String
    let soru: String
    let secenekA: String
    let secenekB: String
    let secenekC: String
    let secenekD: String
    let dogruCevap: Int
    
    init(image: String, questionText: String, choiceA: String, choiceB: String, choiceC: String, choiceD: String, answer: Int){
        questionImage = image
        soru = questionText
        secenekA = choiceA
        secenekB = choiceB
        secenekC = choiceC
        secenekD = choiceD
        dogruCevap = answer
    }
}
