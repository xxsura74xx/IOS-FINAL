
import Foundation

class QuestionBank{
    var list = [Sorular]()
    
    init() {
        list.append(Sorular(image: "flag1", questionText: "Bu İngiliz denizaşırı bölgesi popüler bir vergi cenneti.", choiceA: "A. Haiti", choiceB: "B. Surinam", choiceC: "C. Porto Riko", choiceD: "D. Anguilla", answer: 4))
        
        list.append(Sorular(image: "flag2", questionText: "Bu adadaki en yüksek nokta olan Obama Dağı 2009 yılında cumhurbaşkanının onuruna yeniden adlandırıldı.", choiceA: "A. Dominika", choiceB: "B. Bahamalar", choiceC: "C. Antigua ve Barbuda", choiceD: "Britanya Virjin Adaları", answer: 3))
        
        list.append(Sorular(image: "flag3", questionText: "Bu ülke suyunu bir tuz giderme tesisinden üretiyor ve adadaki elektrik tuz giderme sürecinin bir yan ürünü.", choiceA: "A. Küba", choiceB: "B. Aruba", choiceC: "C. Gaudeloupe", choiceD: "D. Cayman Adaları", answer: 2))
        
        list.append(Sorular(image: "flag4", questionText: "Bu ülkenin muhteşem bir sualtı mağara sistemi var.", choiceA: "A. Bahamalar", choiceB: "B. Venezuela", choiceC: "C. Matinique", choiceD: "D. Dominik Cumhuriyeti", answer: 1))
        
        list.append(Sorular(image: "flag5" , questionText: "Burası Cou-Cou ve Uçan Balık adası. Popüler R&B şarkıcısı Rihanna buradan.", choiceA: "A. Trinidad ve Tobago" , choiceB: "B. Saint Kitts ve Nevis" , choiceC: "C. Grenada" , choiceD: "D. Barbados", answer: 4))
        
        list.append(Sorular(image: "flag15" , questionText: "Rom bu ülkenin milli içeceğidir. Dünyanın en hızlı adamı Usain Bolt buradan çıkmıştır.", choiceA: "A. Jamaika" , choiceB: "B. Saint Vincent ve Grenadinler" , choiceC: "C. Saint Lucia" , choiceD: "D. Guyana", answer: 1))
    }
}
